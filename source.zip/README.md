# qrcToDisk

![screenshot](files/example.png)

Generate archive with sourcecode using qmake and save 
it to disk on desktop and android. Can be used to ship 
source code with application.

